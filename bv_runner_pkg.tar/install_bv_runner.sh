#!/bin/bash
# Cartly runner update: generic best_value rendering (no more operator path).
set -e
cd ~/cartly-content
cp src/runner.py src/runner.py.bak-20261020b
cp /tmp/bv_pkg/src/runner.py src/runner.py
cp /tmp/bv_pkg/templates/best_value_carousel_v2.html templates/
echo "--- checksums"
md5 -q src/runner.py
md5 -q templates/best_value_carousel_v2.html
grep -c "render_best_value" src/runner.py
echo "--- self-test: render_item on the 3 approved best_value items (render only)"
python3 - <<'PY'
import sys
sys.argv = ["runner.py", "--dry-run"]
sys.path.insert(0, "src")
import runner, base64
from pathlib import Path
logo = "data:image/png;base64," + base64.b64encode(Path("assets/logo.png").read_bytes()).decode()
items = runner._rest("GET", "content_items?kind=eq.best_value&status=eq.approved&select=id,kind,payload,caption")
print("approved best_value items:", len(items))
for it in items:
    jobs = runner.render_item(it, logo)
    parts = jobs[0][1].split('<div class="slide">')[1:]
    assert len(jobs) == 3 and len(parts) == 3, (len(jobs), len(parts))
    print("rendered OK", it["id"][:8], it["payload"]["product_name"])
print("BV_SELFTEST PASS")
PY
echo "INSTALL_BV_RUNNER_DONE"
