#!/usr/bin/env python3
"""TikTok mirror for the Cartly runner (Mac install).

Called by runner.py after every successful Instagram publish; posts
the same item to TikTok through Zernio (free tier) so the scheduled
runs drive both platforms unattended. Reuses runner.py's database
channel (PostgREST on the Mac, sb_query on the VM).

Rules (same as the VM publisher, zernio_publisher.py):
- TikTok's consent flags (content_preview_confirmed,
  express_consent_given) are asserted ONLY when a human approval for
  the item is on record in publish_log: an 'approve' row (email link)
  or a 'console_decision' row with response.to = 'approved' (console).
- Never raises: any TikTok failure is logged to publish_log as
  'tiktok_error' and the Instagram run continues unaffected.
- Idempotent: items holding a successful 'tiktok_publish' row are
  skipped, and posts carry Idempotency-Key cartly-<item_id>.
- Uploaded-media fallback: when the GitHub Pages URL form is rejected
  (Zernio's intermittent 400 "Unexpected field: coverUrl"), the file
  is uploaded into Zernio storage via the presign flow and the post
  retried from the media.zernio.com URL.
"""
import json
import os
import urllib.error
import urllib.request

import runner as R

ZBASE = "https://api.zernio.com/v1"
CTYPES = {".jpg": "image/jpeg", ".jpeg": "image/jpeg",
          ".png": "image/png", ".webp": "image/webp",
          ".mp4": "video/mp4", ".mov": "video/quicktime",
          ".webm": "video/webm"}


def _get(path, sql_text):
    if R.USE_REST:
        return R._rest("GET", path)
    return R.sql(sql_text)


def _item(item_id):
    rows = _get(
        f"content_items?id=eq.{item_id}"
        "&select=id,kind,status,caption,asset_urls",
        "select id, kind, status, caption, asset_urls "
        f"from public.content_items where id = '{item_id}';")
    return rows[0] if rows else None


def _log_rows(item_id):
    return _get(
        f"publish_log?item_id=eq.{item_id}&select=action,response",
        "select action, response from public.publish_log "
        f"where item_id = '{item_id}';")


def _already_mirrored(item_id):
    return any(r.get("action") == "tiktok_publish"
               and (r.get("response") or {}).get("http") == 201
               for r in _log_rows(item_id))


def _approved(item_id):
    for r in _log_rows(item_id):
        if r.get("action") == "approve":
            return True
        if (r.get("action") == "console_decision"
                and (r.get("response") or {}).get("to") == "approved"):
            return True
    return False


def _zhttp(method, path, key, body=None, headers=None, raw=None,
           ctype=None, timeout=180):
    hdrs = {}
    if key:
        hdrs["Authorization"] = f"Bearer {key}"
    data = raw
    if body is not None:
        data = json.dumps(body).encode()
        hdrs["Content-Type"] = "application/json"
    if ctype:
        hdrs["Content-Type"] = ctype
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(ZBASE + path,
                                 data=data, method=method, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            text = resp.read().decode()
            return resp.status, (json.loads(text) if text else {})
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        try:
            return e.code, json.loads(text or "{}")
        except ValueError:
            return e.code, {"raw": text[:400]}


def _zpost(key, body, idem_key):
    return _zhttp("POST", "/posts", key, body=body,
                  headers={"Idempotency-Key": idem_key})


def _payload(item, account_id, media):
    is_video = any(m["type"] == "video" for m in media)
    return {
        "content": item["caption"],
        "platforms": [{"platform": "tiktok", "accountId": account_id}],
        "mediaItems": media,
        "publishNow": True,
        "tiktokSettings": ({"privacy_level": "PUBLIC_TO_EVERYONE"}
                           if is_video else {}),
        # True only because mirror() verified the recorded human
        # approval for this item before building this payload.
        "content_preview_confirmed": True,
        "express_consent_given": True,
    }


def _media_for(urls):
    media = []
    for u in urls:
        ext = os.path.splitext(u.split("?")[0])[1].lower()
        kind = "video" if ext in (".mp4", ".mov", ".webm") else "image"
        media.append({"url": u, "type": kind})
    return media


def _uploaded_media(urls, key):
    import tempfile
    media = []
    for u in urls:
        ext = os.path.splitext(u.split("?")[0])[1].lower()
        fd, tmp = tempfile.mkstemp(suffix=ext)
        os.close(fd)
        urllib.request.urlretrieve(u, tmp)
        size = os.path.getsize(tmp)
        status, data = _zhttp("POST", "/media/presign", key, body={
            "filename": os.path.basename(u),
            "contentType": CTYPES.get(ext, "image/jpeg"), "size": size})
        if status >= 400 or "uploadUrl" not in data:
            raise RuntimeError(f"presign -> {status}: "
                               f"{json.dumps(data)[:200]}")
        with open(tmp, "rb") as fh:
            blob = fh.read()
        req = urllib.request.Request(data["uploadUrl"], data=blob,
                                     method="PUT", headers={
                                         "Content-Type":
                                         CTYPES.get(ext, "image/jpeg")})
        with urllib.request.urlopen(req, timeout=600) as resp:
            if resp.status >= 400:
                raise RuntimeError(f"media PUT -> {resp.status}")
        kind = "video" if ext in (".mp4", ".mov", ".webm") else "image"
        media.append({"url": data["publicUrl"], "type": kind})
    return media


def mirror(item_id):
    """Post one published item to TikTok. Returns True on success or
    when already mirrored; False (logged) otherwise. Never raises."""
    try:
        cfg = R.db_config()
        key = cfg.get("zernio_api_key")
        account_id = cfg.get("zernio_tiktok_account_id")
        if not key or not account_id:
            print(f"tiktok mirror {item_id[:8]}: zernio not "
                  "configured; skipped")
            return False
        item = _item(item_id)
        if not item or item.get("status") != "published":
            print(f"tiktok mirror {item_id[:8]}: item not in "
                  "published state; skipped")
            return False
        if _already_mirrored(item_id):
            print(f"tiktok mirror {item_id[:8]}: already mirrored")
            return True
        if not _approved(item_id):
            R.db_log(item_id, "tiktok_skip_no_approval",
                     {"reason": "no approve/console_decision row"})
            print(f"tiktok mirror {item_id[:8]}: no human approval "
                  "on record; skipped")
            return False
        urls = item.get("asset_urls") or []
        if not urls:
            R.db_log(item_id, "tiktok_error",
                     {"error": "no asset_urls recorded"})
            return False
        status, data = _zpost(
            key, _payload(item, account_id, _media_for(urls)),
            f"cartly-{item_id}")
        via = "pages_url"
        if status >= 400 and "coverUrl" in json.dumps(data):
            media = _uploaded_media(urls, key)
            status, data = _zpost(
                key, _payload(item, account_id, media),
                f"cartly-{item_id}-up")
            via = "uploaded_media"
        post = data.get("post") or data
        if status >= 400:
            R.db_log(item_id, "tiktok_error",
                     {"http": status, "via": via,
                      "response": data if isinstance(data, dict)
                      else {"raw": str(data)[:300]}})
            print(f"tiktok mirror {item_id[:8]}: HTTP {status}")
            return False
        R.db_log(item_id, "tiktok_publish",
                 {"http": status, "via": via,
                  "zernio_post_id": post.get("id") or post.get("_id")})
        print(f"tiktok mirror {item_id[:8]}: published via {via}")
        return True
    except Exception as e:  # the Instagram run must never die here
        try:
            R.db_log(item_id, "tiktok_error", {"error": str(e)[:300]})
        except Exception:
            pass
        print(f"tiktok mirror {item_id[:8]} failed: {e}")
        return False
