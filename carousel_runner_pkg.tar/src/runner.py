#!/usr/bin/env python3
"""Cartly content runner (Phase 2) — the recurring publish loop.

For each content_items row in status 'approved' (oldest first, up to the
daily cap from content_config):
  1. render its assets from templates + payload (best_price single,
     best_value carousel, education single) at 1080x1350, JPG —
     reels and story carousels arrive pre-rendered in the package
     under media/ and are only hosted + published here;
  2. stage the JPGs in content/hosting/ (the operator publishes that
     folder to the public website repo under cartly/content/ — the
     runner prints the exact files; BASE_URL must match);
  3. create containers on the Instagram API, wait for FINISHED,
     publish, fetch the permalink;
  4. flip the ledger row to 'published' with media id + permalink and
     write a publish_log row.

Token + config are read from public.content_config through the
Management API helper (sb_query.py). Nothing is ever published from
'approved' items whose recorded prices fall outside the freshness
window in content_config.thresholds (education items are exempt).

Install: see content/RUNNER_INSTALL.md. Run: python3 runner.py [--dry-run]
"""
import base64, json, os, subprocess, sys, time, urllib.request, urllib.parse
from datetime import date, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from render import fill, butter_rows, flour_rows          # noqa: E402  (templates logic)
from build_education import points_html, shoot           # noqa: E402

# Optional local env file (Mac install): KEY=VALUE lines, never committed.
_env_file = ROOT / "runner.env"
if _env_file.exists():
    for _line in _env_file.read_text().splitlines():
        if "=" in _line and not _line.strip().startswith("#"):
            _k, _v = _line.split("=", 1)
            os.environ.setdefault(_k.strip(), _v.strip())

SB = ["python3", str(Path.home() / "workspace/custom-connectors/custom.supabase/bin/sb_query.py"),
      "jvgdyermtsvqdttiwjas", "-"]
BASE = "https://graph.instagram.com/v21.0"
SITE = "https://archesbaitah-bit.github.io/cartly/content"
DRY = "--dry-run" in sys.argv

# Database access: PostgREST with the service key when SUPABASE_URL +
# SUPABASE_SECRET_KEY are set (the Mac install); otherwise the
# Management API helper (Muse's VM).
REST_URL = os.environ.get("SUPABASE_URL", "").rstrip("/")
REST_KEY = os.environ.get("SUPABASE_SECRET_KEY", "")
USE_REST = bool(REST_URL and REST_KEY)

def sql(q):
    p = subprocess.run(SB, input=q, capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(p.stderr[:300] or p.stdout[:300])
    return json.loads(p.stdout)

def _rest(method, path, body=None):
    req = urllib.request.Request(
        REST_URL + "/rest/v1/" + path,
        data=json.dumps(body).encode() if body is not None else None, method=method,
        headers={"apikey": REST_KEY, "Authorization": f"Bearer {REST_KEY}",
                 "content-type": "application/json", "Prefer": "return=representation"})
    with urllib.request.urlopen(req, timeout=60) as r:
        t = r.read().decode()
        return json.loads(t) if t else []

def db_config():
    if USE_REST:
        return {r["key"]: r["value"] for r in _rest("GET", "content_config?select=key,value")}
    return {r["key"]: r["value"] for r in sql("select key, value from public.content_config;")}

def db_approved():
    if USE_REST:
        return _rest("GET", "content_items?status=eq.approved&order=created_at.asc&select=id,kind,payload,caption")
    return sql("select id, kind, payload, caption from public.content_items "
               "where status='approved' order by created_at asc;")

def db_log(item_id, action, response):
    if USE_REST:
        _rest("POST", "publish_log", {"item_id": item_id, "action": action, "response": response})
        return
    sql(f"insert into public.publish_log (item_id, action, response) values "
        f"('{item_id}', '{action}', '{json.dumps(response)}'::jsonb);")

def db_mark_published(item_id, media_id, permalink, urls):
    if USE_REST:
        _rest("PATCH", f"content_items?id=eq.{item_id}",
              {"status": "published", "ig_media_id": media_id, "permalink": permalink,
               "asset_urls": urls, "updated_at": datetime.utcnow().isoformat() + "Z"})
        return
    sql(f"update public.content_items set status='published', ig_media_id='{media_id}', "
        f"permalink='{permalink}', asset_urls=array[{','.join(repr(u) for u in urls)}], updated_at=now() "
        f"where id='{item_id}';")

def api(method, path, token, **params):
    data = urllib.parse.urlencode({"access_token": token, **params}).encode() if method == "POST" else None
    url = f"{BASE}/{path}"
    if method == "GET":
        url += "?" + urllib.parse.urlencode({"access_token": token, **params})
    req = urllib.request.Request(url, data=data, method=method)
    try:
        with urllib.request.urlopen(req, timeout=150) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"API {method} {path}: " + e.read().decode()[:400])

def wait_finished(cid, token, tries=40):
    for _ in range(tries):
        s = api("GET", cid, token, fields="status_code,status")
        if s.get("status_code") == "FINISHED":
            return
        if s.get("status_code") == "ERROR":
            raise RuntimeError(f"container {cid} error: {s}")
        time.sleep(3)
    raise RuntimeError(f"container {cid} not FINISHED in time")

def stage_to_site(names, hosting, item_id):
    """Copy rendered assets into the website repo clone and push.
    Returns True when the site repo exists and the push ran."""
    site = Path.home() / "cartly-site"
    if not site.exists():
        return False
    for n in names:
        subprocess.run(["cp", str(hosting / n), str(site / "cartly" / "content" / n)], check=True)
    subprocess.run(["git", "-C", str(site), "add", "-A"], check=True)
    dirty = subprocess.run(["git", "-C", str(site), "status", "--porcelain"],
                           capture_output=True, text=True).stdout.strip()
    if dirty:
        subprocess.run(["git", "-C", str(site), "commit", "-m", f"content assets {item_id[:8]}"], check=True)
    subprocess.run(["git", "-C", str(site), "pull", "--rebase"], check=True)
    subprocess.run(["git", "-C", str(site), "push"], check=True)
    time.sleep(45)  # GitHub Pages deploy
    return True

def publish_reel(item, token, ig):
    """Reels are pre-rendered on Muse's VM (UGC generation + assembly);
    the MP4 ships in the runner package under media/. The runner only
    hosts it and runs the REELS container flow."""
    name = f"reel_{item['id'][:8]}.mp4"
    mp4 = ROOT / "media" / name
    if not mp4.exists():
        print(f"SKIP {item['id'][:8]}: media/{name} not in the runner package")
        db_log(item["id"], "skip_missing_media", {"file": name})
        return False
    if DRY:
        print(f"DRY reel {item['id'][:8]} ({name})")
        return True
    hosting = ROOT / "hosting"; hosting.mkdir(exist_ok=True)
    subprocess.run(["cp", str(mp4), str(hosting / name)], check=True)
    if not stage_to_site([name], hosting, item["id"]):
        print(f"  NOTE: ~/cartly-site not found — host {name} manually before containers are created")
        return False
    url = f"{SITE}/{name}"
    c = api("POST", f"{ig}/media", token, media_type="REELS", video_url=url,
            caption=item["caption"], share_to_feed="true")
    wait_finished(c["id"], token, tries=200)  # Reels processing can take minutes
    m = api("POST", f"{ig}/media_publish", token, creation_id=c["id"])
    time.sleep(2)
    perm = api("GET", m["id"], token, fields="permalink").get("permalink")
    db_mark_published(item["id"], m["id"], perm, [url])
    db_log(item["id"], "publish", {"media_id": m["id"], "permalink": perm})
    print(f"published reel {item['id'][:8]} -> {perm}")
    return True

def publish_carousel(item, token, ig):
    """Story carousels (template carousel_story_v1) are pre-rendered on
    Muse's VM by build_carousel.py (generated cover photo + data
    slides); the JPG slides ship in the runner package under media/ as
    carousel_<item id8>_<n>.jpg. The runner hosts them and runs the
    carousel container flow, exactly like publish_reel does for MP4s."""
    p = item["payload"]
    n = int(p.get("slides", 5))
    names = [f"carousel_{item['id'][:8]}_{i}.jpg" for i in range(1, n + 1)]
    missing = [name for name in names if not (ROOT / "media" / name).exists()]
    if missing:
        print(f"SKIP {item['id'][:8]}: media files not in the runner package: {missing}")
        db_log(item["id"], "skip_missing_media", {"files": missing})
        return False
    if DRY:
        print(f"DRY carousel {item['id'][:8]} ({n} slides)")
        return True
    hosting = ROOT / "hosting"; hosting.mkdir(exist_ok=True)
    for name in names:
        subprocess.run(["cp", str(ROOT / "media" / name), str(hosting / name)], check=True)
    if not stage_to_site(names, hosting, item["id"]):
        print(f"  NOTE: ~/cartly-site not found — host {names} manually before containers are created")
        return False
    urls = [f"{SITE}/{name}" for name in names]
    children = []
    for u in urls:
        cc = api("POST", f"{ig}/media", token, image_url=u, is_carousel_item="true")
        wait_finished(cc["id"], token); children.append(cc["id"])
    car = api("POST", f"{ig}/media", token, media_type="CAROUSEL",
              children=",".join(children), caption=item["caption"])
    wait_finished(car["id"], token)
    m = api("POST", f"{ig}/media_publish", token, creation_id=car["id"])
    time.sleep(2)
    perm = api("GET", m["id"], token, fields="permalink").get("permalink")
    db_mark_published(item["id"], m["id"], perm, urls)
    db_log(item["id"], "publish", {"media_id": m["id"], "permalink": perm})
    print(f"published carousel {item['id'][:8]} -> {perm}")
    return True

def render_item(item, logo_uri):
    """Returns a list of (filename, html) to screenshot."""
    p = item["payload"]
    kind = item["kind"]
    if kind == "best_price":
        tpl = (ROOT / "templates" / "best_price_single_v1.html").read_text()
        lo, hi = p["lowest"], p["highest"]
        html = fill(tpl, {
            "LOGO": logo_uri, "PRODUCT_NAME": p["product_name"],
            "LOW_PRICE": lo["price"], "LOW_STORE": lo["store"],
            "LOW_PLATFORM": lo["platform"].capitalize(),
            "LOW_PLATFORM_CLASS": "ic" if lo["platform"] == "instacart" else "dd",
            "HIGH_PRICE": hi["price"], "HIGH_STORE": hi["store"],
            "DIFF": p["difference"], "PCT": p["pct_below_highest"],
            "ROWS": butter_rows(p), "OBSERVED": p.get("observed_label", ""),
            "DISCLOSURE": p["disclosure"]})
        return [(f"item_{item['id'][:8]}.jpg", html, "single")]
    if kind == "best_value":
        # The verdict slide's math is item-specific (two-pack totals,
        # premiums). Until a generic verdict template exists, approved
        # Best Value items are rendered + published by an operator pass
        # (the POC flow), never by the unattended runner.
        raise RuntimeError("best_value items take the operator path (item-specific verdict math)")
    if kind == "education":
        tpl = (ROOT / "templates" / "education_v1.html").read_text()
        html = (tpl.replace("{{LOGO}}", logo_uri).replace("{{TITLE}}", p["title"])
                   .replace("{{POINTS}}", points_html([(t,) for t in p["points"]])))
        return [(f"item_{item['id'][:8]}.jpg", html, "single")]
    if kind == "campaign":
        tpl = (ROOT / "templates" / "campaign_v1.html").read_text()
        stats = ""
        if p.get("stats"):
            cells = "".join(f'<div class="stat"><div class="n">{s["n"]}</div><div class="l">{s["l"]}</div></div>'
                            for s in p["stats"])
            stats = f'<div class="stats">{cells}</div>'
        html = (tpl.replace("{{LOGO}}", logo_uri).replace("{{KICKER}}", p["kicker"])
                   .replace("{{TITLE}}", p["title"])
                   .replace("{{POINTS}}", points_html([(t,) for t in p["points"]]))
                   .replace("{{STATS}}", stats)
                   .replace("{{FOOTER}}", p["footer"]))
        return [(f"item_{item['id'][:8]}.jpg", html, "single")]
    raise RuntimeError(f"unknown kind {kind}")

def main():
    cfg = db_config()
    token = cfg["ig_access_token"]; ig = cfg["ig_user_id"]
    cap = int((cfg.get("caps") or {}).get("posts_per_day", 2))
    fresh_days = int((cfg.get("thresholds") or {}).get("freshness_days", 21))
    items = db_approved()
    logo_uri = "data:image/png;base64," + base64.b64encode((ROOT / "assets" / "logo.png").read_bytes()).decode()
    done = 0
    for item in items:
        if done >= cap:
            print(f"daily cap {cap} reached"); break
        p = item["payload"]
        if item["kind"] in ("best_price", "best_value", "carousel") or (item["kind"] == "reel" and p.get("observed_range")):
            last_obs = max(p.get("observed_range") or ["2000-01-01"])
            age = (date.today() - date.fromisoformat(last_obs)).days
            if age > fresh_days:
                print(f"SKIP {item['id'][:8]}: prices {age}d old (gate {fresh_days}d)")
                db_log(item["id"], "skip_stale", {"age_days": age})
                continue
        if item["kind"] == "reel":
            if publish_reel(item, token, ig):
                done += 1
            continue
        if item["kind"] == "carousel":
            if publish_carousel(item, token, ig):
                done += 1
            continue
        try:
            jobs = render_item(item, logo_uri)
        except RuntimeError as e:
            print(f"SKIP {item['id'][:8]}: {e}")
            db_log(item["id"], "skip_operator", {"reason": "best_value operator path"})
            continue
        print(f"{'DRY ' if DRY else ''}publishing {item['kind']} {item['id'][:8]} ({len(jobs)} asset(s))")
        if DRY:
            done += 1; continue
        # Render each asset (carousel slides are separate pages) and host:
        hosting = ROOT / "hosting"; hosting.mkdir(exist_ok=True)
        from PIL import Image
        names = []
        if len(jobs) == 1:
            name, html, _ = jobs[0]
            png = hosting / name.replace(".jpg", ".png")
            shoot(html, str(png))
            Image.open(png).convert("RGB").save(str(hosting / name), "JPEG", quality=92)
            names.append(name)
        else:
            import re as _re
            head = jobs[0][1].split("<body>")[0] + "<body>"
            parts = jobs[0][1].split('<div class="slide">')[1:]
            for (name, _, _), part in zip(jobs, parts):
                part = part.replace("</body></html>", "")
                png = hosting / name.replace(".jpg", ".png")
                shoot(head + '<div class="slide">' + part + "</body></html>", str(png))
                Image.open(png).convert("RGB").save(str(hosting / name), "JPEG", quality=92)
                names.append(name)
        site = Path.home() / "cartly-site"
        if site.exists():
            for n in names:
                subprocess.run(["cp", str(hosting / n), str(site / "cartly" / "content" / n)], check=True)
            subprocess.run(["git", "-C", str(site), "add", "-A"], check=True)
            dirty = subprocess.run(["git", "-C", str(site), "status", "--porcelain"],
                                   capture_output=True, text=True).stdout.strip()
            if dirty:
                subprocess.run(["git", "-C", str(site), "commit", "-m", f"content assets {item['id'][:8]}"], check=True)
            subprocess.run(["git", "-C", str(site), "pull", "--rebase"], check=True)
            subprocess.run(["git", "-C", str(site), "push"], check=True)
            time.sleep(45)  # GitHub Pages deploy
        else:
            print(f"  NOTE: ~/cartly-site not found — host {names} manually before containers are created")
            continue
        urls = [f"{SITE}/{n}" for n in names]
        if len(urls) == 1:
            c = api("POST", f"{ig}/media", token, image_url=urls[0], caption=item["caption"])
            wait_finished(c["id"], token)
            m = api("POST", f"{ig}/media_publish", token, creation_id=c["id"])
        else:
            children = []
            for u in urls:
                cc = api("POST", f"{ig}/media", token, image_url=u, is_carousel_item="true")
                wait_finished(cc["id"], token); children.append(cc["id"])
            car = api("POST", f"{ig}/media", token, media_type="CAROUSEL",
                      children=",".join(children), caption=item["caption"])
            wait_finished(car["id"], token)
            m = api("POST", f"{ig}/media_publish", token, creation_id=car["id"])
        time.sleep(2)
        perm = api("GET", m["id"], token, fields="permalink").get("permalink")
        db_mark_published(item["id"], m["id"], perm, urls)
        db_log(item["id"], "publish", {"media_id": m["id"], "permalink": perm})
        print(f"published {item['id'][:8]} -> {perm}")
        done += 1
    print(f"runner done: {done} item(s)")

if __name__ == "__main__":
    main()
