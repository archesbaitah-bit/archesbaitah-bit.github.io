#!/bin/bash
# Cartly runner update: kind='carousel' support + Snickers carousel media.
set -e
cd ~/cartly-content
cp src/runner.py src/runner.py.bak-20261020
cp /tmp/carousel_pkg/src/runner.py src/runner.py
mkdir -p media
cp /tmp/carousel_pkg/media/carousel_1f7ed5f8_*.jpg media/
echo "--- checksums (runner.py must be 5b0a8b7d6a1b65e9a17471620dd3960c)"
md5 -q src/runner.py
md5 -q media/carousel_1f7ed5f8_*.jpg
grep -c "publish_carousel" src/runner.py
echo "--- self-test: publish_carousel in DRY mode for the Snickers draft"
python3 - <<'PY'
import sys
sys.argv = ["runner.py", "--dry-run"]
sys.path.insert(0, "src")
import runner
items = runner._rest("GET", "content_items?id=eq.1f7ed5f8-eca3-4451-b4b3-cb4b497d8789&select=id,kind,payload,caption")
assert items, "Snickers draft not visible via REST"
ok = runner.publish_carousel(items[0], "dry-token", "17841450577727890")
print("SELFTEST", "PASS" if ok else "FAIL")
PY
echo "--- regression: full runner dry run (publishes nothing)"
python3 src/runner.py --dry-run 2>&1 | tail -6
echo "INSTALL_CAROUSEL_RUNNER_DONE"
